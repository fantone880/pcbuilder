<?php
header('Access-Control-Allow-Origin: *');
	include('connection.php');
	date_default_timezone_set("Asia/Manila");

	$description = $request->description;
	$firstname = $request->firstname;
	$lastname = $request->lastname;
	$userid = $request->userid;
	$postimage = $request->image;
	$profileimage2 = $request->profileimage;

	$timestamp = date("Y-m-d H:i:s");
	echo $timestamp;
	if($description == null){
		echo "donothing";
	}
	else{
		$query = "SELECT * FROM users WHERE id='$userid'";
		$res = mysqli_query($con, $query);
		
		if(mysqli_num_rows($res) == 0){
			$sql = "INSERT INTO post (id, userid, firstname, lastname, description, recorded, profileimage, postimage) VALUES ('', '$userid', '$firstname', '$lastname' ,'$description','$timestamp', '$profileimage2', '$postimage')";
			$result = mysqli_query($con, $sql);
		}
		else{
			while($data = mysqli_fetch_assoc($res)){
				$profileimage = $data['profileimage'];

				$sql = "INSERT INTO post (id, userid, firstname, lastname, description, recorded, profileimage, postimage) VALUES ('', '$userid', '$firstname', '$lastname' ,'$description','$timestamp', '$profileimage', '$postimage')";
				$result = mysqli_query($con, $sql);
			}
		}
	}
?>