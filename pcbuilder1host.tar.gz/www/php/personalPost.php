<?php
	header('Access-Control-Allow-Origin: *');
	include('connection.php');
	date_default_timezone_set("Asia/Manila");
	$userid = $request->userid;
	$sql="SELECT * FROM post WHERE userid='$userid' ORDER BY recorded DESC";
	$result=mysqli_query($con,$sql);
	
	if(mysqli_num_rows($result) == 0){
		$info[] = array();
	}

	while($data = mysqli_fetch_assoc($result)){
			$d = $data['recorded'];
			$da = strtotime($d);
			$date = date("F d, Y", $da); 

			$info[] = array(
				'id'=>$data['id'],
				'firstname'=>$data['firstname'],
				'userid'=>$data['userid'],
				'lastname'=>$data['lastname'],
				'description'=>$data['description'],
				'recorded'=> $date,
				'profileimage'=>$data['profileimage'],
				'postimage'=>$data['postimage']
				);
		}
	echo json_encode($info);
?>