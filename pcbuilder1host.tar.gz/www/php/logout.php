<?php 
	header('Access-Control-Allow-Origin: *');
	include('connection.php');
	$data = json_decode(file_get_contents("php://input"));
	$token = $data->token;
	$con->query("UPDATE users SET token='LOGGED OUT' WHERE token=$token");
?>