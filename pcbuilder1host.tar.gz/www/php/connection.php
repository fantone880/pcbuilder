<?php
	header('Access-Control-Allow-Origin: *');
	$con = mysqli_connect('localhost', 'id2431512_admin', 'password', 'id2431512_gamers_community');
	if(!$con){
		echo "ERROR CONNECTING TO DATABASE";
	}

	$post = file_get_contents("php://input");
	$request = json_decode($post);

?>