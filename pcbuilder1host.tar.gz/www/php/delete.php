<?php
	header('Access-Control-Allow-Origin: *');
	include('connection.php');

	$id = $request->id;

	$sql = "DELETE FROM post WHERE id='$id'";
	$result = mysqli_query($con, $sql);
?>