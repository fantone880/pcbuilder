<?php

	header('Access-Control-Allow-Origin: *');
	include('connection.php');
	date_default_timezone_set("Asia/Manila");

	$id = $request->id;

	$sql = "SELECT * FROM post WHERE id='$id'";
	$result = mysqli_query($con, $sql);

	while($data = mysqli_fetch_assoc($result)){
		$info[] = array(
			'id'=>$data['id'],
			'description'=>$data['description'],
			'postimage'=>$data['postimage']
		);
	}

	echo json_encode($info);

?>