<?php

	header('Access-Control-Allow-Origin: *');
	include('connection.php');
	date_default_timezone_set("Asia/Manila");

	$description = $request->description;
	$id = $request->id;
	$postimage = $request->postimage;

	if($postimage == null){
		$sql = "UPDATE post SET description='$description', recorded=now() WHERE id='$id'";
		$result=mysqli_query($con, $sql);
	}
	else{
		$sql = "UPDATE post SET description='$description', postimage='$postimage', recorded=now() WHERE id='$id'";
		$result = mysqli_query($con, $sql);
	}
	

?>