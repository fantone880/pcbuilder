<?php
	header('Access-Control-Allow-Origin: *');
	include('connection.php');

	$email =  $request->email;
	$password =  $request->password;
	$array = array();

	$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
	$result = mysqli_query($con, $sql);

	if(mysqli_num_rows($result) > 0){

		while($data = mysqli_fetch_assoc($result)){
			array_push($array, "success");
			array_push($array, $data);
		}
	}
	else{
		array_push($array, "nosuccess");
	}
	echo json_encode($array);
	
?>