<?php

	header('Access-Control-Allow-Origin: *');
	include('connection.php');

	$id = $request->id;
	$image = $request->image;

	$sql="UPDATE users SET profileimage='$image' WHERE id='$id'";
	$sql2="UPDATE post SET profileimage='$image' WHERE userid='$id'";
	$result = mysqli_query($con, $sql);
	$result2 = mysqli_query($con, $sql2);
?>