<?php
	header('Access-Control-Allow-Origin: *');

    include("connection.php");

    $email = $request->email;
    $firstname = $request->firstname;
    $lastname = $request->lastname;
    $password = $request->password;

    if(($email=="") || ($firstname=="") || ($password=="")){
    	echo "donothing";
    }
    else{
    $sql = "INSERT INTO users (id, email, firstname, lastname, password) VALUES ('','$email','$firstname', '$lastname', '$password')";
    $result = mysqli_query($con,$sql);
}  
    
?> z