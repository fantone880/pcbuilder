<?php

	header('Access-Control-Allow-Origin: *');
	include('connection.php');

	$id = $request->id;

	$sql="SELECT profileimage FROM users WHERE id='$id'";
	$result = mysqli_query($con, $sql);

		while($data = mysqli_fetch_assoc($result)){
			$decode = $data['profileimage'];
			$info[] = $decode;
		}
	echo json_encode($info);
?>
