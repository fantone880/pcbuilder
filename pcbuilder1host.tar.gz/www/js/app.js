var app = angular.module('starter', ['ionic', 'ngCordova', 'starter.controllers'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(false);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
})

app.config(function($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
  $ionicConfigProvider.tabs.position('bottom');
  $urlRouterProvider.otherwise('/');
  $stateProvider
    .state('login', {
    url: '/',
    templateUrl:'templates/login.html'
    })

    .state('register', {
    url: '/register',
    templateUrl:'templates/register.html'
    })    

    .state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'templates/tabs.html'
  })

  .state('tab.dash', {
    url: '/dash',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-dash.html',
      }
    }
  })

  .state('tab.chats', {
      url: '/chats',
      views: {
        'tab-chats': {
          templateUrl: 'templates/tab-chats.html',
        }
      }
    })
    .state('tab.chat-detail', {
      url: '/chats/:chatId',
      views: {
        'tab-chats': {
          templateUrl: 'templates/chat-detail.html',
        }
      }
    })

  .state('tab.account', {
    url: '/account',
    views: {
      'tab-account': {
        templateUrl: 'templates/tab-account.html',
      }
    }
  })

  .state('tab.post',{
    url: '/post',
    views:{
      'tab-account':{
        templateUrl: 'templates/post.html',
      }
    }
  })
    .state('tab.profile',{
    url: '/profile',
    views:{
      'tab-account':{
        templateUrl: 'templates/editProfile.html',
      }
    }
  })

  .state('tab.camera',{
    url: '/camera',
    views:{
      'tab-account':{
        templateUrl: 'templates/camera.html',
      }
    }
  })

  .state('tab.edit',{
    url: '/edit',
    views:{
      'tab-account':{
        templateUrl: 'templates/editpost.html',
      }
    }
  });

});
