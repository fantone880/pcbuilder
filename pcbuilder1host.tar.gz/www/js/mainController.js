app.controller("MainController", function ($scope, $state, $http, AuthenticationService){
    //If user is not logged in
	var token;
	if (localStorage['token']){
    token = JSON.parse(localStorage['token']);
	} else {
	token = "something stupid";
	}
	AuthenticationService.checkToken(token);
	
	$scope.logout = function(a){
		var data = {
			token: token
		}
		console.log(a);
		$http.post('http://localhost/pcbuilder1/www/php/logout.php', data).success(function(response){
			console.log(response)
			localStorage.clear();
			$state.go("login");
		}).error(function(error){
			console.error(error);
		})
	}
})