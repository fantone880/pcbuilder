window.fbAsyncInit = function() {
    // FB.Event.subscribe('auth.statusChange', function(auth){
    //     if(auth.status==='connected'){
    //         // subscribe to event, and do some magic stuff when status changes
    //     }
    // });
    FB.init({
      appId            : '246096359232718',
      autoLogAppEvents : true,
      xfbml            : true,
      version          : 'v2.10',
      status		   : true
    });
  	
    FB.getLoginStatus(function(response){
    	if(response.status === 'connected'){
    		// we are connected
    	}else if(response.status === 'not_authorized'){
    		// not auth
    	}else{
    		// we are not logged in to Facebook.
    	}
    });

};

  (function(d, s, id){
     var js, fjs = d.getElementsByTagName(s)[0];
     if (d.getElementById(id)) {return;}
     js = d.createElement(s); js.id = id;
     js.src = "//connect.facebook.net/en_US/sdk.js";
     fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
  