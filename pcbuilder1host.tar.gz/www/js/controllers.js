angular.module('starter.controllers', ['ionic'])

	.controller('register', function($scope, $http, $state, $ionicPopup){
		$scope.data = {};
		$scope.signUp = function(email, firstname, lastname, password){

			var firstname = $scope.data.firstname;
			var lastname = $scope.data.lastname;
			var password = $scope.data.password;
			var email = $scope.data.email;

			console.log(email+' '+firstname+' ' + lastname +' '+password);

			if(firstname != null && password != null && email != null){
				$http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
				$http({
					url: 'http://pcbuilders.000webhostapp.com/php/signup.php',
					method: 'POST',
					data: {
						'firstname': firstname,
						'lastname': lastname,
						'password': password,
						'email': email
					}
				})
				.then(function(response){
						if(response.data == "donothing"){
						var misMatch = $ionicPopup.alert({
							title: 'Something\'s not right',
							template:'Please fillup the form to complete the registration.'
						});
						misMatch.then(function(response2){
							console.log("email: misMatch | Password: misMatch");
							$scope.data.email = "";
							$scope.data.password = "";
						})
					}
					else{
						var char = {
							'firstname': firstname,
							'lastname': lastname,
							'password': password,
							'email': email
						};
						console.log(char);
						localStorage.setItem('loginVar', JSON.stringify(char));
						$state.go('login');
					
					}
					
				})
			}
			else if((email == "" || email == null) && ((firstname == "") || (firstname == null)) && (password == "" || password == null)){
				$scope.emailError = true;
				$scope.userError = true;
				$scope.passError = true;
			}
			else if((email == "" || email == null) && (firstname == "" || firstname == null)){
				$scope.emailError = true;
				$scope.userError = true;
				console.log(email+username);
			}
			else if((email == "" || email == null)  && (password == "" || password == null)){
				$scope.emailError = true;
				$scope.passError = true;
			}
			else if((firstname == "" || firstname == null) && (password == "" || password == null)){
				$scope.userError = true;
				$scope.passError = true;
			}
			else if(email == "" || email == null){ 
				$scope.emailError = true;
			}
			else if(firstname == "" || firstname == null){
				$scope.userError = true;
			}
			else if(password == "" || password == null){
				$scope.passError = true;
			}
		}

		$scope.errMsgGone = function(){
			$scope.emailError = false;
			$scope.userError= false;
			$scope.passError = false;
		}
	})
	.controller('login', function($scope, $http, $state, $ionicPopup, $rootScope){
		$scope.data = {};
		$scope.login = function(email, password){
			var email = $scope.data.email;
			var password = $scope.data.password;;

			console.log("email: "+email+" | Password: "+password);
			if(email != null && password != null){
				$http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
				$http({
					url: 'http://pcbuilders.000webhostapp.com/php/login.php',
					method: 'POST',
					data: {
						'email': email,
						'password': password
					}
				})
				.then(function(response){
					console.log(response);
					if(response.data[0] == 'success'){
						
						localStorage.setItem('loginVar', JSON.stringify(response.data[1]));
						var get = JSON.parse(localStorage.getItem('loginVar'));
						var firstname = get.firstname;
						var lastname = get.lastname
						var logSuccess = $ionicPopup.alert({
							title: 'Welcome '+firstname+" "+lastname,
							template:'You\'ve successfully logged in!'
						});
						logSuccess.then(function(response2){
							console.log("loginSuccess");
						})
						$scope.data.email = "";
						$scope.data.password = "";
						$state.go('tab.account');
						
					}
					else{
						var misMatch = $ionicPopup.alert({
							title: 'Something\'s not right',
							template:'The email or password you\'ve entered doesn\'t match any account. Please try again.'
						});
						misMatch.then(function(response2){
							console.log("email: misMatch | Password: misMatch");
							$scope.data.email = "";
							$scope.data.password = "";
						})
					}
				})
				.catch(function(data) {
					var popup = $ionicPopup.alert({
						title: "Error",
						template: "To be able to connect. Please input your correct IP address."
					});
					popup.then(function(rest){
						console.log("Error successfully catch");
					})
				})
			}
			else if(email == null && password == null){
				$scope.userError = true;
				$scope.passError = true;
			}
			else if(email == null){
				$scope.userError = true;
			}
			else if(password == null){
				$scope.passError = true;
			}

		}
		$scope.errMsgGone = function(){
			$scope.userError = false;
			$scope.passError = false;
		}
		$scope.registerState = function(){
			$state.go('register');
		}

		$scope.facebook = {
		'username': "",
		'email': ""
		};
	$scope.onFBLogin = function(){
		FB.login(function(response){
			if(response.authResponse){
				FB.api('/me', 'GET', {fields: 'email, first_name, last_name, id, picture'}, function(response){
					var fbdata = {
						'id': response.id,
						'firstname': response.first_name,
						'lastname': response.last_name,
						'email': response.email,
						'profileimage': response.picture.data.url				
					};

					localStorage.setItem('loginVar', JSON.stringify(fbdata));
					var get = JSON.parse(localStorage.getItem('loginVar'));
						var firstname = get.firstname;
						var logSuccess = $ionicPopup.alert({
							title: 'Welcome '+firstname,
							template:'You\'ve successfully logged in!'
						});
						logSuccess.then(function(response2){
							console.log("loginSuccess");
						})
	 					$scope.data.email = "";
						$scope.data.password = "";

						$state.go('tab.account');
				});
			}else{
				//error
			}
		}, {
			scope: 'email, user_likes',
			return_scopes: true
		});
	}

	})

	.controller('profile', function($scope, $http, $ionicPopup, $state, $window, $interval){
		var get = JSON.parse(localStorage.getItem('loginVar'));
		$scope.email = get.email;
		$scope.firstname = get.firstname;
		$scope.lastname = get.lastname;
		$scope.password = get.password;
		var id = get.id;
	
		$http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
		$http({
			url: 'http://pcbuilders.000webhostapp.com/php/profilepicture.php',
			method: 'POST',
			data: {
				'id': id
			}
		}).then(function(response){
			$scope.image = response.data[0];
			$scope.image = get.profileimage;
		})

		$scope.editProfile = function(){
			$state.go('tab.profile');
		}

		$scope.logout = function(){
			var logOut = $ionicPopup.confirm({
				title: 'Confirmation',
				template: 'Are you sure you want to logout?'
			});
			logOut.then(function(respo){
				if(respo){
					localStorage.setItem('loginVar', null);
					$state.go("login");
					$window.location.reload();
					console.log("logoutSucess");
				}
				else{
					console.log("logoutFailed");
				}
			})	
		}
		$scope.postrig = function(){
			$state.go('tab.post');
		}
	})

	.controller('checkuser',function($rootScope){
		$rootScope.previousState;
		$rootScope.currentState;

		$rootScope.$on('$stateChangeStart',function(event, toState, toParams, fromState, fromParams){
			var user = localStorage.getItem('loginVar');
			if((user != 'null' && toState.name == 'login' )||(user != 'null' && toState.name == 'register' )|| (user == 'null' && fromState.name == 'login')){
				event.preventDefault();
			}
			console.log(toState);
		})
	})

	.controller('postRig', function($scope, $rootScope, $http, $window, $state, $cordovaCamera, $ionicPopup){
		$scope.data = {};
		$scope.post = function(description){
			var image = document.getElementById('response').value;
			var get = JSON.parse(localStorage.getItem('loginVar'));
			var userid = get.id;
			var firstname = get.firstname;
			var lastname = get.lastname;
			var description = $scope.data.description;
			var profileimage = get.profileimage;

				$http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
				$http({
					url: 'http://pcbuilders.000webhostapp.com/php/post.php',
					method: 'POST',
					data: {
						'image': image,
						'description': description,
						'firstname': firstname,
						'lastname': lastname,
						'userid': userid,
						'profileimage': profileimage
					}
				}).then(function(response){
					if(response.data != "donothing"){
						$rootScope.$emit('parentMethod', {});
						$rootScope.$emit('parentCommunity', {});
						$state.go('tab.account');
						
					}
					else{
						var noData = $ionicPopup.alert({
							title: 'Something\'s not right',
							template:'Please input the following fields to be able to post.'
						});
							noData.then(function(response){
							console.log(response);
						})
					}
				})
			
		}
		$scope.takePicture = function(response){

			 var options = {
                    quality: 50,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.CAMERA,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 400,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
		}
	    $scope.choosePicture = function () {
                  var options = {
                    quality: 50,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 400,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
   
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
                }

	})
	.controller('personalPost', function($scope, $rootScope,$http, $ionicPopup, $window, $interval,  $cordovaSocialSharing, $state, $ionicModal, $timeout){
		$http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
		
		$rootScope.$on('parentMethod',function(){
			$scope.parent();
		});
		$scope.parent =function(){
			getData();
		}

		getData();	

	function getData(){
		var get = JSON.parse(localStorage.getItem('loginVar'));
		var userid = get.id;
		$scope.emptyPost = "";
	
		$http({
			url: 'http://pcbuilders.000webhostapp.com/php/personalPost.php',
			method: 'POST',
			data:{
				'userid': userid
			}
		}).then(function(response){
				if(response.data[0] == ""){
					$scope.myValue=true;
					$scope.myValue2 = false;
					$scope.emptyPost = "Nothing to show!";
				}
				else{
					$scope.myValue = false;
					$scope.myValue2 = true;
					$scope.posts = response.data;
					console.log(response);
				}
		});
	}
		$scope.deletepost = function(id){
			var getid = id;
			var confirm = $ionicPopup.confirm({
				title: 'Confirmation',
				template: 'Are you sure you want to delete this post?'
			});
			confirm.then(function(respo){
				if(respo){
					$http({
						url: 'http://pcbuilders.000webhostapp.com/php/delete.php',
						method: 'POST',
						data:{
							'id': getid
						}
					})
					.then(function(response){
						getData();
						$rootScope.$emit('parentCommunity', {});
					})
				}
				else{
					console.log("Canceled");
				}
			})
		}
		$scope.editpost = function(id){
			$scope.data = {};
			var id = id;

			$http({
				url: 'http://pcbuilders.000webhostapp.com/php/editpost.php',
				method: 'POST',
				data:{
					'id': id
				}
			}).then(function(response){
				$state.go('tab.edit');
				$scope.data = response.data;
				var store = response.data[0];
				localStorage.setItem('editPost', JSON.stringify(store));
				console.log(store);
			})
		}

		$scope.share = function(msg, img, link){
				 $cordovaSocialSharing
    				.shareViaFacebook(msg, img, link)
    				.then(function(result) {
      					console.log(result);
    				}, function(err) {
     	 				console.log(err);
    				 });			
		}
	})

	.controller('edit', function($scope, $http, $cordovaCamera){
		$scope.data = {};
		var get = JSON.parse(localStorage.getItem('editPost'));
		var id = get.id;
		var description = get.description;
		var postimage = get.postimage;

		$scope.description = description;
		$scope.postimage = postimage;


		$scope.takePicture = function(response){
			 var options = {
                    quality: 50,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.CAMERA,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 400,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.postimage = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
		}
	    $scope.choosePicture = function () {
                  var options = {
                    quality: 50,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 400,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.postimage = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
                }
	})

	.controller('editNav', function($scope, $rootScope, $http,$ionicPopup,$state, $window){
		$scope.cancel = function(){
			localStorage.setItem('editPost', null); 
			$state.go('tab.account');
		}
		$scope.post = function(){
			var get = JSON.parse(localStorage.getItem('editPost'));
			var id = get.id;
			var description = document.getElementById('description').value;
			var postimage = document.getElementById('response').value;

			var confirm = $ionicPopup.confirm({
				title: 'Confirmation',
				template: 'Are you sure you want to save changes?'
			});
			confirm.then(function(respo){
				if(respo){
					$http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
					$http({
						url: 'http://pcbuilders.000webhostapp.com/php/updatepost.php',
						method: 'POST',
						data:{
							'id': id,
							'description':description,
							'postimage':postimage
						}
					}).then(function(response){
						$rootScope.$emit('parentMethod', {});
						$rootScope.$emit('parentCommunity', {});
						$state.go('tab.account');
						localStorage.setItem('editPost', null);
					});
				}
				else{
					console.log("Canceled");
				}
			})
		}
	})
	.controller('communityPost', function($scope, $rootScope, $http, $interval){

		$rootScope.$on('parentCommunity',function(){
			$scope.parent();
		});
		$scope.parent =function(){
			community();
		}


	community();
	function community(){
		$http({
			url: 'http://pcbuilders.000webhostapp.com/php/communityPost.php',
			method: 'POST'
		})
		.then(function(response){
				$scope.posts = response.data;
				console.log(response.data);			
		})
	}

	})

	.controller('uploadPhotoFromFile', function($scope,$http,$state, $ionicPopup){
		$scope.uploadImage = function(){

			var get = JSON.parse(localStorage.getItem('loginVar'));
			var id = get.id;
			var base64 = document.getElementById('response').value;
			
			var confirm = $ionicPopup.confirm({
				title: 'Confirmation',
				template: 'Are you sure you want to save changes?'
			});
			confirm.then(function(respo){
				if(respo){
					$http.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
					$http({
						url: 'http://pcbuilders.000webhostapp.com/php/updateImage.php',
						method: 'POST',
						data:{
							'id': id,
							'image': base64
						}
					})
					.then(function(response){
						document.getElementById('response').value = "";
						$state.go('tab.account');
					})
				}
				else{
					console.log("Canceled");
				}
			})
		}
	})

	.controller('takePhoto', function($scope, $http, $cordovaCamera){
		$scope.takePicture = function(){
			 var options = {
                    quality: 50,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.CAMERA,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 400,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        console.log(err);
                    });
		}
	    $scope.choosePicture = function () {
                  var options = {
                    quality: 50,
                    destinationType: Camera.DestinationType.DATA_URL,
                    sourceType: Camera.PictureSourceType.PHOTOLIBRARY,
                    allowEdit: true,
                    encodingType: Camera.EncodingType.JPEG,
                    targetWidth: 400,
                    targetHeight: 300,
                    popoverOptions: CameraPopoverOptions,
                    saveToPhotoAlbum: false
                };
                    $cordovaCamera.getPicture(options).then(function (imageData) {
                        $scope.imgURI = "data:image/jpeg;base64," + imageData;
                    }, function (err) {
                        // An error occured. Show a message to the user
                    });
        }
	});